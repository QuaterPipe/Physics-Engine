#pragma once
#include "Curve.hpp"
#include "Line.hpp"
#include "Math.hpp"
#include "Matrix.hpp"
#include "Vector.hpp"
#define IS_BIG_ENDIAN (*(WORD *)"\0\x2" == 0x200)
