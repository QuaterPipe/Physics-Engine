#include "../testing/Testing.hpp"
int main()
{
	Demo();
	return 0;
}